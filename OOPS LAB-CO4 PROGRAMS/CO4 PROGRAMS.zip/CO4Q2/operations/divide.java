package CO4Q2.operations;

public class divide implements calculate{
    public void cal(int x, int y){
        int div = x/y;
        System.out.println(x+"/"+y+" = "+div);

}}

