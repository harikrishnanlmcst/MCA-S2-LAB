package CO4Q2.operations;

public class add implements calculate{

    public void cal(int x, int y){
        int sum = x+y;
        System.out.println("Sum of Numbers = "+sum);
    }

}
