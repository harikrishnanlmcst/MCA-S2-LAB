package CO4Q2.operations;

public class subtract implements calculate{
    public void cal(int x, int y){
        int sub = x-y;
        System.out.println("Difference of Numbers = "+sub);
    }
}
