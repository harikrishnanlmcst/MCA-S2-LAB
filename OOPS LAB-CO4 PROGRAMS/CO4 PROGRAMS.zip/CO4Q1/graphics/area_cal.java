package CO4Q1.graphics;

public interface area_cal {
    void area();
}
