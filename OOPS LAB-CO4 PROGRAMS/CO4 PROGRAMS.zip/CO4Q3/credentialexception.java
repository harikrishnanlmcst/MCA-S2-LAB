package CO4Q3;

public class credentialexception extends Exception{
    public credentialexception(String s){
        super(s);
    }
}
