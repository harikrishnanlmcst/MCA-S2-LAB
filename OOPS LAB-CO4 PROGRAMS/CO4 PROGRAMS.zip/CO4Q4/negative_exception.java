package CO4Q4;

public class negative_exception extends  Exception{
    public negative_exception(String s){
        super(s);
    }
}
